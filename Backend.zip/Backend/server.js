const express = require("express")
const cors = require("cors")

const suggestionRoutes = require("./routes/suggestionRoutes")

const app = express()

app.use(cors())
app.use(express.json())
app.use(express.static("public"))

app.use("/api", suggestionRoutes)

app.listen(3000, () => {
 console.log("Mini Copilot running on port 3000")
})