const OLLAMA_URL = "http://localhost:11434/api/generate"
const MODEL = "phi3.5"

export { OLLAMA_URL, MODEL }