const axios = require("axios")

exports.generate = async(prompt)=>{

 const response = await axios.post(
  "http://localhost:11434/api/generate",
  {
   model:"phi3.5",
   prompt:prompt,
   stream:false
  }
 )

 return response.data.response
}