exports.findSimilar = (inputCode) => {
  const programs = require("../data/programs.json")

  const inputTokens = tokenize(inputCode)

  const scored = programs.map(p => {
    const tokens = tokenize(p.code)
    return {
      code: p.code,
      score: similarity(inputTokens, tokens)
    }
  })

  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(p => p.code)
}

function tokenize(text) {
  return text
    .toLowerCase()
    .split(/\W+/)   // split by non-words
    .filter(Boolean);
}

function similarity(tokens1, tokens2) {
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);

  const intersection = [...set1].filter(x => set2.has(x));
  
  return intersection.length / Math.max(set1.size, set2.size);
}