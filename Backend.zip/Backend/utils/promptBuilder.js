module.exports = (code, examples)=>{

    const exampleText = examples.map(e=>e.code).join("\n")
   
    return `
   You are a coding assistant for PMU_CARES library only give HINT dont give entire code.
   
   Here are example programs:
   
   ${exampleText}
   
   Complete the following sudo program:
   
   ${code}
   `
   }