// utils/validator.js

const allowedKeywords = [
    "PMU_CARES",
    "Pin",
    "sleep",
    "servo",
    "sensor",
    "temperature",
    "water",
    "display",
    "import",
    "led",
  ]
  
  exports.isPMUCaresCode = (code) => {
    const lowerCode = code.toLowerCase()
  
    return allowedKeywords.some(keyword =>
      lowerCode.includes(keyword.toLowerCase())
    )
  }