const express = require("express")
const router = express.Router()

const { getSuggestion } = require("../controllers/suggestionController")

router.post("/suggest", getSuggestion)

module.exports = router