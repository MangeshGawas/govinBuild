const aiService = require("../services/aiService")
const searchService = require("../services/searchService")
const { isPMUCaresCode } = require("../utils/validator")  // ✅ IMPORT

exports.getSuggestion = async (req, res) => {
  try {
    const code = req.body.code

    // ✅ VALIDATION HERE
    if (!isPMUCaresCode(code)) {
      return res.json({
        suggestion: "❌ This is not related to PMU_CARES library."
      })
    }

    const similarPrograms = searchService.findSimilar(code)

//     const prompt = `
// You are an expert in PMU_CARES MicroPython library.

// Reference Programs:
// ${similarPrograms.join("\n\n")}

// User Code:
// ${code}

// Complete the code using PMU_CARES only.
// Only return code.
// `

// const prompt = `
// You are an expert in PMU_CARES MicroPython library.

// Reference Programs:
// ${similarPrograms.join("\n\n")}

// User Code:
// ${code}

// Analyze the user's code and provide:

// 1. Efficiency of the written code
// 2. What improvements can be made
// 3. What additional functionality can be added using PMU_CARES
// 4. Any mistakes or missing logic

// Rules:
// - Do NOT rewrite entire code
// - Do NOT generate full program
// - Only give suggestions
// - Keep response short and structured

// Return Format:

// Efficiency:
// <your answer>

// Improvements:
// <your answer>

// You can add:
// <your answer>

// Mistakes (if any):
// <your answer>
// `

const prompt = `
You are an expert in PMU_CARES MicroPython custom library.

IMPORTANT:
- PMU_CARES is a custom library
- Reference Programs syntax are correct
- Do NOT mark custom syntax as mistake
- Only mark logical or missing functionality mistakes
- If syntax looks unusual but exists in reference, treat it as valid

Reference Programs:
${similarPrograms.join("\n\n")}

User Code:
${code}

Analyze the code and respond VERY SHORT and POINT-WISE.

Rules:
- Keep answer under 6–8 bullet points
- No long explanations
- No code generation
- Only suggestions
- Trust PMU_CARES syntax

Return Format:

Accuracy:
• Overall Accuracy: XX%
• Logic Accuracy: XX%
• Library Usage Accuracy: XX%

Efficiency:
• point

Improve:
• point

Can Add:
• point

Mistakes:
• point (Only logical mistakes, not custom syntax)

Hint:
• point (Only logical hint, not custom syntax)

Scoring Rules:
- 90–100% → Excellent
- 75–89% → Good
- 60–74% → Needs Improvement
- Below 60% → Incorrect / Incomplete

`

    const suggestion = await aiService.generate(prompt)

    res.json({ suggestion })

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Server error" })
  }
}